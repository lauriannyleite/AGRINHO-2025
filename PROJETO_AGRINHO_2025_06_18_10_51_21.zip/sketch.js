function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let truckX;
let truckY;
let truckWidth = 150;
let truckHeight = 100;
let velocidadeTruck = 5; // Velocidade de movimento do truck

let hortalias = []; // Array para armazenar as hortaliças
let numHortalias = 5;
let tamanhoHortalica = 20;

let obstaculos = []; // Array para armazenar os obstáculos
let numObstaculos = 3;
let tamanhoObstaculo = 40;
let velocidadeObstaculo = 3;

let pontuacao = 0;
let vida = 3; // O truck tem 3 vidas
let jogoAcabou = false;

function setup() {
  createCanvas(800, 400);
  truckX = width / 2 - truckWidth / 2; // Centraliza o truck no início
  truckY = height - truckHeight - 20; // Posição do truck na parte inferior da tela

  // Inicializa as hortaliças
  for (let i = 0; i < numHortalias; i++) {
    hortalias.push(criarObjetoAleatorio(tamanhoHortalica));
  }

  // Inicializa os obstáculos
  for (let i = 0; i < numObstaculos; i++) {
    obstaculos.push(criarObjetoAleatorio(tamanhoObstaculo));
  }
}

function draw() {
  background(135, 206, 235); // Céu
  
  // Desenha o chão
  fill(100, 150, 50);
  rect(0, height - 50, width, 50);

  if (!jogoAcabou) {
    // --- Movimento do Truck (Controlado pelo Jogador) ---
    if (keyIsDown(LEFT_ARROW)) {
      truckX -= velocidadeTruck;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      truckX += velocidadeTruck;
    }

    // Limita o truck dentro da tela
    truckX = constrain(truckX, 0, width - truckWidth);

    // --- Desenha o Truck ---
    // Carroceria
    fill(200, 50, 50);
    rect(truckX, truckY, 120, 70); // Corrigi a posição Y para alinhar com o truckY

    // Cabine
    fill(150, 0, 0);
    rect(truckX + 100, truckY - 20, 50, 90); // Corrigi a posição Y

    // Rodas
    fill(50);
    ellipse(truckX + 30, truckY + 70, 40, 40); // Ajuste para ficar abaixo da carroceria
    ellipse(truckX + 90, truckY + 70, 40, 40); // Ajuste para ficar abaixo da carroceria

    // --- Desenha e Atualiza Hortaliças ---
    fill(0, 180, 0); // Verde para as hortaliças
    for (let i = 0; i < hortalias.length; i++) {
      let h = hortalias[i];
      ellipse(h.x, h.y, h.size, h.size);
      h.y += h.velocidade; // Hortaliças caem

      // Verifica colisão com o truck
      if (dist(h.x, h.y, truckX + truckWidth / 2, truckY + truckHeight / 2) < (h.size / 2 + truckWidth / 4)) {
        // Colisão com o truck
        pontuacao++;
        hortalias.splice(i, 1); // Remove a hortaliça coletada
        hortalias.push(criarObjetoAleatorio(tamanhoHortalica)); // Adiciona uma nova hortaliça
      }

      // Se a hortaliça sair da tela, recria ela
      if (h.y > height) {
        hortalias.splice(i, 1);
        hortalias.push(criarObjetoAleatorio(tamanhoHortalica));
      }
    }

    // --- Desenha e Atualiza Obstáculos ---
    fill(100, 100, 100); // Cinza para os obstáculos
    for (let i = 0; i < obstaculos.length; i++) {
      let o = obstaculos[i];
      rect(o.x, o.y, o.size, o.size); // Obstáculos como quadrados
      o.y += velocidadeObstaculo; // Obstáculos caem

      // Verifica colisão com o truck
      if (dist(o.x + o.size / 2, o.y + o.size / 2, truckX + truckWidth / 2, truckY + truckHeight / 2) < (o.size / 2 + truckWidth / 4)) {
        // Colisão com o truck
        vida--;
        obstaculos.splice(i, 1); // Remove o obstáculo colidido
        obstaculos.push(criarObjetoAleatorio(tamanhoObstaculo)); // Adiciona um novo obstáculo

        if (vida <= 0) {
          jogoAcabou = true;
        }
      }

      // Se o obstáculo sair da tela, recria ele
      if (o.y > height) {
        obstaculos.splice(i, 1);
        obstaculos.push(criarObjetoAleatorio(tamanhoObstaculo));
      }
    }

    // --- Exibe Pontuação e Vidas ---
    fill(0);
    textSize(24);
    text("Pontuação: " + pontuacao, 10, 30);
    text("Vidas: " + vida, 10, 60);
  } else {
    // --- Tela de Fim de Jogo ---
    fill(0);
    textSize(48);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2 - 30);
    textSize(24);
    text("Pontuação Final: " + pontuacao, width / 2, height / 2 + 20);
    text("Pressione 'R' para Reiniciar", width / 2, height / 2 + 60);
  }
}

// Função para criar um novo objeto (hortaliça ou obstáculo)
function criarObjetoAleatorio(tamanho) {
  return {
    x: random(width), // Posição X aleatória
    y: random(-height, 0), // Posição Y aleatória acima da tela
    size: tamanho,
    velocidade: random(1, 3) // Velocidade de queda aleatória
  };
}

// Reinicia o jogo ao pressionar 'R'
function keyPressed() {
  if (jogoAcabou && key === 'r' || key === 'R') {
    reiniciarJogo();
  }
}

function reiniciarJogo() {
  pontuacao = 0;
  vida = 3;
  jogoAcabou = false;

  // Limpa e recria hortaliças
  hortalias = [];
  for (let i = 0; i < numHortalias; i++) {
    hortalias.push(criarObjetoAleatorio(tamanhoHortalica));
  }

  // Limpa e recria obstáculos
  obstaculos = [];
  for (let i = 0; i < numObstaculos; i++) {
    obstaculos.push(criarObjetoAleatorio(tamanhoObstaculo));
  }
}